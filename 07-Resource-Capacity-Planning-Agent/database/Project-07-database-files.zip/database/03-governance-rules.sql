-- Project 07 governance rules
-- Exact thresholds used during the build.

INSERT INTO governance_rules
(rule_code, threshold_pct, severity, approval_authority, escalation_hours, active)
VALUES
('UTIL-085', 85,  'Warning',  'Project Manager',    72, true),
('UTIL-100', 100, 'High',     'PMO Manager',        48, true),
('UTIL-120', 120, 'Critical', 'Portfolio Manager', 24, true)
ON CONFLICT (rule_code) DO UPDATE SET
  threshold_pct = EXCLUDED.threshold_pct,
  severity = EXCLUDED.severity,
  approval_authority = EXCLUDED.approval_authority,
  escalation_hours = EXCLUDED.escalation_hours,
  active = EXCLUDED.active;

-- Scenario recommendation weighting used in Project 07:
-- Effectiveness = 60%
-- Governance    = 40%
-- AI explains/recommends; it does not recalculate deterministic metrics
-- and does not make the final governance approval.
