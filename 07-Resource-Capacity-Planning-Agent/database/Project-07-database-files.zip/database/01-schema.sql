-- Project 07 | AI Resource, Capacity & Governance Planning Agent
-- Repository-ready schema reconstruction.
-- For an exact live-schema export, use pg_dump against ai_resource_capacity.

BEGIN;

CREATE TABLE IF NOT EXISTS projects (
  project_id varchar(30) PRIMARY KEY,
  project_name varchar(200) NOT NULL,
  priority varchar(20),
  status varchar(30),
  start_date date,
  end_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS resources (
  resource_id varchar(30) PRIMARY KEY,
  resource_name varchar(200) NOT NULL,
  role varchar(150),
  department varchar(150),
  standard_hours numeric(8,2) DEFAULT 40,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS resource_capacity (
  capacity_id bigserial PRIMARY KEY,
  resource_id varchar(30) NOT NULL REFERENCES resources(resource_id),
  week_start_date date NOT NULL,
  standard_hours numeric(8,2) NOT NULL DEFAULT 40,
  leave_hours numeric(8,2) NOT NULL DEFAULT 0,
  holiday_hours numeric(8,2) NOT NULL DEFAULT 0,
  training_hours numeric(8,2) NOT NULL DEFAULT 0,
  bau_hours numeric(8,2) NOT NULL DEFAULT 0,
  available_hours numeric(8,2) GENERATED ALWAYS AS (
    standard_hours
    - COALESCE(leave_hours,0)
    - COALESCE(holiday_hours,0)
    - COALESCE(training_hours,0)
    - COALESCE(bau_hours,0)
  ) STORED,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(resource_id, week_start_date)
);

CREATE TABLE IF NOT EXISTS resource_demand (
  demand_id bigserial PRIMARY KEY,
  project_id varchar(30) NOT NULL REFERENCES projects(project_id),
  resource_id varchar(30) NOT NULL REFERENCES resources(resource_id),
  activity_name varchar(250) NOT NULL,
  week_start_date date NOT NULL,
  planned_hours numeric(8,2) NOT NULL,
  activity_priority varchar(20),
  critical_path boolean NOT NULL DEFAULT false,
  start_date date,
  end_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT uq_resource_demand_business_key
    UNIQUE(resource_id, project_id, week_start_date, activity_name)
);

CREATE TABLE IF NOT EXISTS governance_rules (
  rule_id bigserial PRIMARY KEY,
  rule_code varchar(30) UNIQUE NOT NULL,
  threshold_pct numeric(8,2) NOT NULL,
  severity varchar(20) NOT NULL,
  approval_authority varchar(150) NOT NULL,
  escalation_hours integer NOT NULL,
  active boolean DEFAULT true
);

CREATE TABLE IF NOT EXISTS capacity_conflicts (
  conflict_id bigserial PRIMARY KEY,
  resource_id varchar(30) NOT NULL REFERENCES resources(resource_id),
  week_start_date date NOT NULL,
  conflict_type varchar(50) NOT NULL DEFAULT 'RESOURCE_OVERALLOCATION',
  available_hours numeric(8,2) NOT NULL,
  demand_hours numeric(8,2) NOT NULL,
  utilization_pct numeric(8,2) NOT NULL,
  overallocation_hours numeric(8,2) NOT NULL,
  severity varchar(20) NOT NULL,
  status varchar(30) NOT NULL DEFAULT 'Open',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(resource_id, week_start_date, conflict_type)
);

CREATE TABLE IF NOT EXISTS capacity_scenarios (
  scenario_id bigserial PRIMARY KEY,
  scenario_name varchar(250) NOT NULL,
  conflict_id bigint NOT NULL REFERENCES capacity_conflicts(conflict_id),
  scenario_description text,
  created_by varchar(150),
  created_at timestamptz DEFAULT now(),
  critical_path_impact boolean,
  priority_impact varchar(30),
  creates_secondary_conflict boolean,
  governance_score numeric(8,2)
);

CREATE TABLE IF NOT EXISTS scenario_allocations (
  scenario_allocation_id bigserial PRIMARY KEY,
  scenario_id bigint NOT NULL REFERENCES capacity_scenarios(scenario_id),
  project_id varchar(30) REFERENCES projects(project_id),
  resource_id varchar(30) REFERENCES resources(resource_id),
  activity_name varchar(250),
  original_week_start_date date,
  proposed_week_start_date date,
  original_hours numeric(8,2),
  proposed_hours numeric(8,2),
  change_type varchar(50),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS capacity_decisions (
  decision_id bigserial PRIMARY KEY,
  conflict_id bigint NOT NULL REFERENCES capacity_conflicts(conflict_id),
  scenario_id bigint REFERENCES capacity_scenarios(scenario_id),
  recommendation_text text,
  decision varchar(30) DEFAULT 'Pending',
  approval_status varchar(30) DEFAULT 'Pending',
  decision_owner varchar(150),
  decision_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS capacity_decision_audit (
  audit_id bigserial PRIMARY KEY,
  conflict_id bigint REFERENCES capacity_conflicts(conflict_id),
  decision_id bigint REFERENCES capacity_decisions(decision_id),
  action_type varchar(60) NOT NULL,
  previous_status varchar(30),
  new_status varchar(30),
  action_by varchar(150),
  action_source varchar(100),
  action_timestamp timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS weekly_capacity_reports (
  report_id bigserial PRIMARY KEY,
  report_week_start date NOT NULL UNIQUE,
  report_week_end date NOT NULL,
  generated_at timestamptz DEFAULT now(),
  total_available_capacity_hours numeric(12,2),
  total_demand_hours numeric(12,2),
  portfolio_utilization_pct numeric(8,2),
  overloaded_resources integer,
  critical_resources integer,
  recommendations_created integer,
  decisions_approved integer,
  decisions_rejected integer,
  pending_approvals integer,
  conflicts_without_decision integer,
  report_status varchar(30) DEFAULT 'Generated'
);

CREATE TABLE IF NOT EXISTS weekly_capacity_report_exceptions (
  report_exception_id bigserial PRIMARY KEY,
  report_id bigint NOT NULL REFERENCES weekly_capacity_reports(report_id),
  resource_id varchar(30) REFERENCES resources(resource_id),
  conflict_id bigint REFERENCES capacity_conflicts(conflict_id),
  decision_id bigint REFERENCES capacity_decisions(decision_id),
  utilization_pct numeric(8,2),
  overallocation_hours numeric(8,2),
  severity varchar(20),
  governance_status varchar(50),
  decision_status varchar(30)
);

COMMIT;
