-- Project 07 sanitized test data
-- Capacity/demand dates intentionally use 2025.

INSERT INTO projects
(project_id, project_name, priority, status, start_date, end_date)
VALUES
('PRJ-001', 'Sample Enterprise Project', 'Critical', 'Active', '2025-08-01', '2025-12-31'),
('PRJ-002', 'Sample Mobile Project', 'High', 'Active', '2025-08-01', '2025-12-31'),
('PRJ-004', 'Sample API Project', 'High', 'Active', '2025-08-01', '2025-12-31'),
('PRJ-005', 'Cloud Migration Program', 'High', 'Active', '2025-08-01', '2025-12-31')
ON CONFLICT (project_id) DO NOTHING;

INSERT INTO resources
(resource_id, resource_name, role, department, standard_hours)
VALUES
('RES-001', 'Solution Architect A', 'Solution Architect', 'Architecture', 40),
('RES-002', 'Project Manager A', 'Project Manager', 'PMO', 40),
('RES-006', 'Integration Engineer A', 'Integration Engineer', 'Engineering', 40),
('RES-007', 'Cloud Architect A', 'Cloud Architect', 'Architecture', 40)
ON CONFLICT (resource_id) DO NOTHING;

INSERT INTO resource_capacity
(resource_id, week_start_date, standard_hours, leave_hours, holiday_hours, training_hours, bau_hours)
VALUES
('RES-001', '2025-08-18', 40,0,0,0,0),
('RES-002', '2025-08-18', 40,0,0,0,0),
('RES-006', '2025-08-18', 40,0,0,0,8),
('RES-007', '2025-08-18', 40,0,0,4,4)
ON CONFLICT (resource_id, week_start_date) DO NOTHING;

INSERT INTO resource_demand
(project_id, resource_id, activity_name, week_start_date, planned_hours, activity_priority, critical_path)
VALUES
('PRJ-001','RES-001','Solution Architecture Design','2025-08-18',24,'Critical',true),
('PRJ-002','RES-001','Mobile Integration Design','2025-08-18',20,'High',true),
('PRJ-004','RES-001','API Architecture Review','2025-08-18',12,'High',false),
('PRJ-001','RES-002','Portfolio Delivery Coordination','2025-08-18',30,'High',false),
('PRJ-002','RES-002','Integration Delivery Coordination','2025-08-18',20,'High',false),
('PRJ-001','RES-006','ERP Integration Engineering','2025-08-18',20,'High',true),
('PRJ-002','RES-006','Mobile Integration Engineering','2025-08-18',18,'High',true),
('PRJ-005','RES-007','Cloud Architecture Design','2025-08-18',24,'High',true),
('PRJ-001','RES-007','ERP Integration Review','2025-08-18',16,'Critical',false)
ON CONFLICT (resource_id, project_id, week_start_date, activity_name) DO NOTHING;

-- Expected deterministic test results:
-- RES-001: 56h demand / 40h capacity = 140%, 16h over
-- RES-002: 50h / 40h = 125%, 10h over
-- RES-007: 40h / 32h = 125%, 8h over
-- RES-006: 38h / 32h = 118.75%, 6h over
