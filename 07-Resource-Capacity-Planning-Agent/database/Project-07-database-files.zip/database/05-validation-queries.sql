-- Project 07 validation queries

-- Weekly utilization
SELECT *
FROM vw_weekly_resource_utilization
WHERE week_start_date = DATE '2025-08-18'
ORDER BY utilization_pct DESC NULLS LAST;

-- Conflict register
SELECT *
FROM capacity_conflicts
WHERE week_start_date = DATE '2025-08-18'
ORDER BY utilization_pct DESC;

-- Canonical conflict type check
SELECT conflict_type, COUNT(*)
FROM capacity_conflicts
GROUP BY conflict_type;

-- Scenario ranking
SELECT *
FROM vw_scenario_recommendations
ORDER BY conflict_id, recommendation_rank, scenario_id;

-- Best scenario per conflict
SELECT *
FROM vw_best_scenario_per_conflict
ORDER BY conflict_id;

-- Governance state
SELECT *
FROM vw_weekly_capacity_governance
WHERE week_start_date = DATE '2025-08-18'
ORDER BY utilization_pct DESC NULLS LAST;

-- Governance decisions
SELECT *
FROM capacity_decisions
ORDER BY created_at DESC, decision_id DESC;

-- Audit trail
SELECT *
FROM capacity_decision_audit
ORDER BY action_timestamp DESC, audit_id DESC;

-- Portfolio summary
SELECT *
FROM vw_weekly_portfolio_capacity_summary
WHERE week_start_date = DATE '2025-08-18';

-- Weekly historical reports
SELECT *
FROM weekly_capacity_reports
ORDER BY generated_at DESC;

-- Weekly report exceptions
SELECT wr.report_id, wr.report_week_start, e.*
FROM weekly_capacity_reports wr
JOIN weekly_capacity_report_exceptions e ON e.report_id = wr.report_id
ORDER BY wr.generated_at DESC, e.utilization_pct DESC;

-- Idempotency check: should return zero rows
SELECT resource_id, project_id, week_start_date, activity_name, COUNT(*)
FROM resource_demand
GROUP BY resource_id, project_id, week_start_date, activity_name
HAVING COUNT(*) > 1;

-- Generated available-hours check
SELECT
  resource_id, week_start_date, standard_hours,
  leave_hours, holiday_hours, training_hours, bau_hours,
  available_hours,
  standard_hours - leave_hours - holiday_hours - training_hours - bau_hours
    AS recalculated_available_hours
FROM resource_capacity
ORDER BY week_start_date, resource_id;
