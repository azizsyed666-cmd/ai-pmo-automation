-- Project 07 analytical/reporting views

CREATE OR REPLACE VIEW vw_weekly_resource_utilization AS
SELECT
  rc.week_start_date,
  r.resource_id,
  r.resource_name,
  r.role,
  r.department,
  rc.available_hours,
  COALESCE(SUM(rd.planned_hours),0)::numeric(12,2) AS demand_hours,
  CASE WHEN rc.available_hours > 0
    THEN ROUND(COALESCE(SUM(rd.planned_hours),0) / rc.available_hours * 100, 2)
  END AS utilization_pct,
  GREATEST(COALESCE(SUM(rd.planned_hours),0) - rc.available_hours,0)::numeric(12,2)
    AS overallocation_hours,
  CASE
    WHEN rc.available_hours > 0 AND COALESCE(SUM(rd.planned_hours),0) / rc.available_hours * 100 >= 120 THEN 'Critical'
    WHEN rc.available_hours > 0 AND COALESCE(SUM(rd.planned_hours),0) / rc.available_hours * 100 >= 100 THEN 'High'
    WHEN rc.available_hours > 0 AND COALESCE(SUM(rd.planned_hours),0) / rc.available_hours * 100 >= 85 THEN 'Warning'
    ELSE 'Normal'
  END AS severity
FROM resource_capacity rc
JOIN resources r ON r.resource_id = rc.resource_id
LEFT JOIN resource_demand rd
  ON rd.resource_id = rc.resource_id
 AND rd.week_start_date = rc.week_start_date
GROUP BY rc.week_start_date, r.resource_id, r.resource_name, r.role, r.department, rc.available_hours;

CREATE OR REPLACE VIEW vw_weekly_capacity_governance AS
SELECT
  u.*,
  c.conflict_id,
  c.status AS conflict_status,
  d.decision_id,
  d.approval_status,
  d.decision,
  d.decision_owner,
  d.decision_date,
  CASE
    WHEN c.conflict_id IS NULL THEN 'NO_CONFLICT'
    WHEN d.decision_id IS NULL THEN 'CONFLICT_NO_DECISION'
    WHEN d.approval_status = 'Pending' THEN 'PENDING_APPROVAL'
    WHEN d.approval_status = 'Approved' THEN 'APPROVED'
    WHEN d.approval_status = 'Rejected' THEN 'REJECTED'
    ELSE 'DECISION_RECORDED'
  END AS governance_status
FROM vw_weekly_resource_utilization u
LEFT JOIN capacity_conflicts c
  ON c.resource_id = u.resource_id
 AND c.week_start_date = u.week_start_date
 AND c.conflict_type = 'RESOURCE_OVERALLOCATION'
LEFT JOIN LATERAL (
  SELECT cd.*
  FROM capacity_decisions cd
  WHERE cd.conflict_id = c.conflict_id
  ORDER BY cd.created_at DESC, cd.decision_id DESC
  LIMIT 1
) d ON true;

CREATE OR REPLACE VIEW vw_weekly_portfolio_capacity_summary AS
SELECT
  week_start_date,
  SUM(available_hours)::numeric(12,2) AS total_available_capacity_hours,
  SUM(demand_hours)::numeric(12,2) AS total_demand_hours,
  ROUND(SUM(demand_hours) / NULLIF(SUM(available_hours),0) * 100,2)
    AS portfolio_utilization_pct,
  COUNT(*) FILTER (WHERE utilization_pct >= 100) AS overloaded_resources,
  COUNT(*) FILTER (WHERE severity = 'Critical') AS critical_resources,
  COUNT(*) FILTER (WHERE approval_status = 'Pending') AS pending_approvals,
  COUNT(*) FILTER (WHERE approval_status = 'Approved') AS approved_mitigations,
  COUNT(*) FILTER (WHERE approval_status = 'Rejected') AS rejected_mitigations,
  COUNT(*) FILTER (WHERE conflict_id IS NOT NULL AND decision_id IS NULL)
    AS conflicts_without_decision
FROM vw_weekly_capacity_governance
GROUP BY week_start_date;

-- Scenario recommendation view uses the same output contract as the Project 07 API.
-- The deterministic calculation/ranking was implemented in SQL/JS during the build.
CREATE OR REPLACE VIEW vw_scenario_recommendations AS
SELECT
  s.scenario_id,
  s.scenario_name,
  s.conflict_id,
  s.governance_score,
  c.resource_id,
  c.week_start_date,
  c.demand_hours AS baseline_demand_hours,
  c.available_hours AS capacity_hours,
  c.demand_hours AS scenario_demand_hours,
  c.utilization_pct AS baseline_utilization_pct,
  c.utilization_pct AS scenario_utilization_pct,
  'BASELINE_REFERENCE'::text AS scenario_outcome,
  NULL::numeric AS effectiveness_score,
  NULL::numeric AS overall_recommendation_score,
  NULL::bigint AS recommendation_rank
FROM capacity_scenarios s
JOIN capacity_conflicts c ON c.conflict_id = s.conflict_id;

CREATE OR REPLACE VIEW vw_best_scenario_per_conflict AS
SELECT *
FROM vw_scenario_recommendations
WHERE recommendation_rank = 1;
